import torch
from Nmetrics import evaluate
import numpy as np
from tqdm import tqdm
import torch.nn as nn
import copy
import argparse
import random
import time
import geomloss
import torch.nn.functional as F
import load_data as loader
from network import Network
import networkx as nx
from loss import Loss
from alignment import alignment
from datasets import Data_Sampler, TrainDataset_Com, TrainDataset_All, TrainDataset_All_nei
from contrastive import original_contras_fea, modified_contras_loss, CE_contrastive
import os
from sklearn.cluster import KMeans
from sklearn.neighbors import NearestNeighbors
from utils import NormalizeFeaTorch, get_Similarity, clustering, euclidean_dist
import torch.autograd
from sklearn.metrics.pairwise import cosine_similarity
from scipy.optimize import linear_sum_assignment
import matplotlib.pyplot as plt
from sklearn.manifold import TSNE
import ot
import scipy.io as io

torch.autograd.set_detect_anomaly(True)


def seed_everything(SEED=42):  # 应用不同的种子产生可复现的结果
    random.seed(SEED)
    np.random.seed(SEED)
    torch.manual_seed(SEED)
    torch.cuda.manual_seed(SEED)
    torch.cuda.manual_seed_all(SEED)
    torch.backends.cudnn.benchmark = True  # keep True if all the input have same size.


def process_matrix(matrix):
    """
    对输入的 v*v 矩阵进行每行求和、取倒数和归一化处理，使其行和为1，返回 v*1 的 tensor 向量。

    参数:
    matrix (numpy.ndarray): 输入的 v*v 矩阵。

    返回:
    torch.Tensor: 归一化后的 v*1 tensor 向量。
    """
    # 每行求和
    row_sums = np.sum(matrix, axis=1)

    # 对向量取倒数
    reciprocal = 1 / row_sums

    # 归一化处理使行和为1
    normalized = reciprocal / np.sum(reciprocal)

    # 转换为 v*1 的 tensor
    tensor_vector = torch.tensor(normalized, dtype=torch.float32).view(-1, 1)

    return tensor_vector


def pretrain(model, opt_pre, args, device, X_com, Y_com):
    train_dataset = TrainDataset_Com(X_com, Y_com)
    batch_sampler = Data_Sampler(train_dataset, shuffle=False, batch_size=args.batch_size, drop_last=False)
    train_loader = torch.utils.data.DataLoader(dataset=train_dataset, batch_sampler=batch_sampler)

    t_progress = tqdm(range(args.pretrain_epochs), desc='Pretraining')
    for epoch in t_progress:
        tot_loss = 0.0
        loss_fn = torch.nn.MSELoss()
        for batch_idx, (xs, ys) in enumerate(train_loader):
            for v in range(args.V):
                xs[v] = torch.squeeze(xs[v]).to(device)
            opt_pre.zero_grad()
            zs, xrs = model(xs)
            loss_list = []
            for v in range(args.V):
                loss_value = loss_fn(xs[v], xrs[v])
                loss_list.append(loss_value)
            loss = sum(loss_list)
            loss.backward()
            opt_pre.step()
            tot_loss += loss.item()
        # print('Epoch {}'.format(epoch + 1), 'Loss:{:.6f}'.format(tot_loss / len(train_loader)))

    fea_emb = []
    for v in range(args.V):
        fea_emb.append([])

    all_dataset = TrainDataset_Com(X_all, Y)
    batch_sampler_all = Data_Sampler(all_dataset, shuffle=False, batch_size=args.batch_size, drop_last=False)
    all_loader = torch.utils.data.DataLoader(dataset=all_dataset, batch_sampler=batch_sampler_all)

    with torch.no_grad():
        for batch_idx2, (xs2, _) in enumerate(all_loader):
            for v in range(args.V):
                xs2[v] = torch.squeeze(xs2[v]).to(device)
            zs2, xrs2 = model(xs2)
            for v in range(args.V):
                zs2[v] = zs2[v].cpu()
                fea_emb[v] = fea_emb[v] + zs2[v].tolist()

    for v in range(args.V):
        fea_emb[v] = torch.tensor(fea_emb[v])

    return fea_emb


def calculate_weights_from_ot_matrix_softmax(G):
    v = G.shape[0]

    # 计算相似度矩阵 S
    S = -G

    # 计算每个视图的权重
    w = np.exp(S) / np.sum(np.exp(S), axis=1, keepdims=True)

    # 将权重标准化并转换为 PyTorch tensor
    w_normalized = np.sum(w, axis=1)
    w_tensor = torch.tensor(w_normalized, dtype=torch.float32)

    return w_tensor


def train_align(model, opt_align, args, device, X, Y, Miss_vecs, H, H_NEI, view_matrix):
    t_progress = tqdm(range(args.align_epochs), desc='Alignment')
    H_MEMORY = H
    view_matrix_temp = view_matrix
    max_view_graph = generate_max_view_graph(view_matrix_temp)

    weight_vector = process_matrix(view_matrix_temp).to(device)
    train_dataset = TrainDataset_All_nei(X, Y, Miss_vecs, H_MEMORY, H_NEI)
    batch_sampler = Data_Sampler(train_dataset, shuffle=False, batch_size=args.Batch_Align, drop_last=False)
    train_loader = torch.utils.data.DataLoader(dataset=train_dataset, batch_sampler=batch_sampler)
    for epoch in t_progress:
        # fea_all = []
        # for v in range(args.V):
        # fea_all.append([])
        for batch_idx, (x, y, miss_vec, h_batch, h_nei_batch) in enumerate(train_loader):
            opt_align.zero_grad()
            ###### 计算loss_recon ######
            loss_fn = torch.nn.MSELoss().to(device)
            # loss_fn2 = torch.nn.MSELoss().to(device)
            loss_list_recon = []
            # loss_list_recon_nei = []
            for v in range(args.V):
                x[v] = torch.squeeze(x[v]).to(device)
                y[v] = torch.squeeze(y[v]).to(device)
                miss_vec[v] = torch.squeeze(miss_vec[v]).to(device)
                h_nei_batch[v] = torch.squeeze(h_nei_batch[v]).to(device)
            z, xr, x_com, z_filleds = model.miss_fill(x, miss_vec, h_nei_batch)
            ############################################################################################补全使用每个batch内的样本补全

            for v in range(args.V):
                loss_list_recon.append(loss_fn(x_com[v], xr[v]))
            loss_recon = sum(loss_list_recon)

            ##########################################################################################batch内邻居对比
            loss_list_con_nei = []
            for v in range(args.V):
                l_tmp2 = modified_contras_loss(z_filleds[v], 1)

                loss_list_con_nei.append(weight_vector[v] * l_tmp2)
            loss_con_neis = sum(loss_list_con_nei)
            # print('loss_con_neis', loss_con_neis)
            ##########################################################################################计算view graph的对比
            loss_list_con_view_graph = []
            for edge in max_view_graph.edges():
                start_node, end_node = edge
                criterion = Loss(z_filleds[0].shape[0], 0.5, 0.5,
                                 0.5).cuda()
                l_tmp3 = criterion.contrastive_loss(z_filleds[start_node], z_filleds[end_node])

                loss_list_con_view_graph.append(l_tmp3)
            loss_con_view_graph = sum(loss_list_con_view_graph)

            loss_total = loss_recon + alph * loss_con_neis + beta * loss_con_view_graph  # 改


            loss_total.backward()
            opt_align.step()

        fea_emb = []
        for v in range(args.V):
            fea_emb.append([])

        train_dataset = TrainDataset_All_nei(X, Y, Miss_vecs, H_MEMORY, H_NEI)
        batch_sampler = Data_Sampler(train_dataset, shuffle=False, batch_size=args.Batch_Align, drop_last=False)
        train_loader = torch.utils.data.DataLoader(dataset=train_dataset, batch_sampler=batch_sampler)

        with torch.no_grad():
            for batch_idx2, (xs2, y, miss_vec, h_batch, h_nei_batch) in enumerate(train_loader):
                for v in range(args.V):
                    xs2[v] = torch.squeeze(xs2[v]).to(device)
                    y[v] = torch.squeeze(y[v]).to(device)
                    miss_vec[v] = torch.squeeze(miss_vec[v]).to(device)
                    h_nei_batch[v] = torch.squeeze(h_nei_batch[v]).to(device)
                z, xr, x_com, z_filleds = model.miss_fill(xs2, miss_vec, h_nei_batch)
                for v in range(args.V):
                    z_filleds[v] = z_filleds[v].cpu()
                    fea_emb[v] = fea_emb[v] + z_filleds[v].tolist()

        for v in range(args.V):
            fea_emb[v] = torch.tensor(fea_emb[v])
        fea_end = []
        for v in range(args.V):
            fea_end.append(copy.deepcopy(fea_emb[v]).cpu())
        Labels = Y[0]
        estimator = KMeans(n_clusters=args.K)

    return fea_emb


def cost_func(a, b, p=2, metric='cosine'):
    """ a, b in shape: (B, N, D) or (N, D)
    """
    assert type(a) == torch.Tensor and type(b) == torch.Tensor, 'inputs should be torch.Tensor'
    if metric == 'euclidean' and p == 1:
        return geomloss.utils.distances(a, b)
    elif metric == 'euclidean' and p == 2:
        return geomloss.utils.squared_distances(a, b)
    else:
        if a.dim() == 3:
            x_norm = a / a.norm(dim=2)[:, :, None]
            y_norm = b / b.norm(dim=2)[:, :, None]
            M = 1 - torch.bmm(x_norm, y_norm.transpose(-1, -2))
        elif a.dim() == 2:
            x_norm = a / a.norm(dim=1)[:, None]
            y_norm = b / b.norm(dim=1)[:, None]
            M = 1 - torch.mm(x_norm, y_norm.transpose(0, 1))
        M = pow(M, p)
        return M


def view_graph_gen(view, fea_emb):
    entreg = .1
    p = 2
    M = torch.zeros((view, view))
    for v in range(view):
        fea_emb[v] = torch.tensor(fea_emb[v])
    metric = 'cosine'
    OTLoss = geomloss.SamplesLoss(
        loss='sinkhorn', p=p,
        cost=lambda a, b: cost_func(a, b, p=p, metric=metric),
        blur=entreg ** (1 / p), backend='tensorized')
    # pW = OTLoss(fea_emb[0], fea_emb[1])
    for v in range(view):
        for j in range(args.V):
            M[v, j] = OTLoss(fea_emb[v], fea_emb[j])
    return M


def find_common_elements_with_index(array1, array2):
    # 创建字典用于存储数字和它们在原始数组中的索引
    index_dict = {}
    for i, num in enumerate(array1):
        if num in index_dict:
            index_dict[num].append(i)
        else:
            index_dict[num] = [i]

    # 找到共同的数字及它们在原始数组中的索引
    common_numbers = []
    index_array1 = []
    index_array2 = []
    for j, num2 in enumerate(array2):
        if num2 in index_dict:
            for index in index_dict[num2]:
                common_numbers.append(num2)
                index_array1.append(index)
                index_array2.append(j)

    return common_numbers, index_array1, index_array2


def find_common_elements_with_index_sparse(view1_missing, view2_missing):
    # 取反处理，将缺失的地方为0的缺失指示矩阵转换为1表示缺失，0表示不缺失
    view1_not_missing = view1_missing
    view2_not_missing = view2_missing
    # 通过位运算找到两个视图中都不缺失的样本
    common_samples = view1_not_missing & view2_not_missing
    # 找到不缺失样本的索引
    common_samples_indices = np.where(common_samples)[0]
    # 返回不缺失样本的索引
    return common_samples_indices


def cost_func(a, b, p=2, metric='cosine'):
    """ a, b in shape: (B, N, D) or (N, D)
    """
    assert type(a) == torch.Tensor and type(b) == torch.Tensor, 'inputs should be torch.Tensor'
    if metric == 'euclidean' and p == 1:
        return geomloss.utils.distances(a, b)
    elif metric == 'euclidean' and p == 2:
        return geomloss.utils.squared_distances(a, b)
    else:
        if a.dim() == 3:
            x_norm = a / a.norm(dim=2)[:, :, None]
            y_norm = b / b.norm(dim=2)[:, :, None]
            M = 1 - torch.bmm(x_norm, y_norm.transpose(-1, -2))
        elif a.dim() == 2:
            x_norm = a / a.norm(dim=1)[:, None]
            y_norm = b / b.norm(dim=1)[:, None]
            M = 1 - torch.mm(x_norm, y_norm.transpose(0, 1))
        M = pow(M, p)
        return M


def generate_max_view_graph(ot_distances):
    # 构建初始完全连接图
    num_nodes = ot_distances.shape[0]
    G = nx.complete_graph(num_nodes)
    # 循环去除最大的边，直到存在某个点去掉最大边后没有边连接
    while True:
        # 计算当前图中所有边的 OT 距离
        edge_weights = {(u, v): ot_distances[u][v] for u, v in G.edges}
        # print("edge_weights:", edge_weights)
        # 找到具有最大 OT 距离的边
        max_edge = max(edge_weights, key=edge_weights.get)
        # print("len(max_edge):", len(max_edge))
        max_weight = edge_weights[max_edge]
        # 移除最大的边
        G.remove_edge(*max_edge)
        # 如果某个点去掉最大边后没有边连接，则停止循环
        if not nx.is_connected(G):
            G.add_edge(*max_edge)
            break

    return G


def find_nearest_non_missing_view(indicator_matrix, distance_matrix):
    n, v = indicator_matrix.shape
    index_matrix = np.empty((n, v), dtype=int)

    for i in range(n):
        for j in range(v):
            if indicator_matrix[i, j] == 0:  # If sample i is missing in view j
                nearest_non_missing_view = find_nearest_non_missing_view_for_sample(i, j, indicator_matrix,
                                                                                    distance_matrix)
                index_matrix[i, j] = nearest_non_missing_view
            else:
                index_matrix[i, j] = -1  # Placeholder for non-missing samples

    return index_matrix


def find_nearest_non_missing_view_for_sample(sample_index, missing_view_index, indicator_matrix, distance_matrix):
    v = indicator_matrix.shape[1]
    distances = distance_matrix[missing_view_index]

    sorted_indices = np.argsort(distances)
    for index in sorted_indices:
        if indicator_matrix[sample_index, index] == 1:  # Found nearest non-missing view
            return index

    return -1


if __name__ == '__main__':
    torch.autograd.set_detect_anomaly(True)
    my_data_dic = loader.ALL_data3

    ALPAs = [0.001]
    betas = [0.01]

    #  Sources_3   Washington  synthetic3d  UCI_digit  Cora  YouTubeFace10_4Views  YouTubeFace20_4Views
    for i_d in my_data_dic:
        for alph in ALPAs:
            for beta in betas:
                pre_epochs = 200  # 200 预训练epoch
                align_epochs = 50
                Batch_Align = 2048  # 对齐阶段batch_size
                # print('alph,loss_con_neis', alph)
                # print('beta,loss_con_view_graph', beta)
                for indx in range(5, 6):
                    print('alph,loss_con_neis', alph)
                    print('beta,loss_con_view_graph', beta)
                    data_para = my_data_dic[i_d]  # 改
                    print(data_para)
                    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
                    missrate = indx / 10  # 缺失率
                    print('missrate:', missrate)
                    lr_pre = 0.0005  # 0.0005 预训练学习率
                    lr_align = 0.0001  # 0.0001 对齐学习率
                    Batch = 512  # 256  预训练阶段batch_size
                    para_loss = [1e-3, 1e-3]  # 超参数
                    feature_dim = 32  # embedding维度, 等于clusters

                    seed_everything(42)  # 应用不同的种子产生可复现的结果

                    parser = argparse.ArgumentParser(description='main')
                    parser.add_argument('--dataset', default=data_para)
                    parser.add_argument('--batch_size', default=Batch, type=int)
                    parser.add_argument('--Batch_Align', default=Batch_Align, type=int)
                    parser.add_argument('--missrate', default=missrate, type=float)
                    parser.add_argument('--lr_pre', default=lr_pre, type=float)
                    parser.add_argument('--lr_align', default=lr_align, type=float)
                    parser.add_argument('--para_loss', default=para_loss, type=float)
                    parser.add_argument('--pretrain_epochs', default=pre_epochs, type=int)
                    parser.add_argument('--align_epochs', default=align_epochs, type=int)
                    parser.add_argument("--feature_dim", default=feature_dim)
                    parser.add_argument("--V", default=data_para['V'])
                    parser.add_argument("--K", default=data_para['K'])
                    parser.add_argument("--N", default=data_para['N'])
                    parser.add_argument("--view_dims", default=data_para['n_input'])
                    # parser.add_argument("--view_meaning", default=data_para['view_meaning'])

                    args = parser.parse_args()
                    print('+' * 30, ' Parameters ', '+' * 30)
                    print(args)
                    print('+' * 75)

                    X, Y, missindex, X_com, Y_com, index_com, index_incom, unfilled_X_complete, unfilled_Y_complete = loader.load_data(
                        args.dataset, args.missrate)
                    Indications = []
                    X_all = []
                    for i in range(args.V):
                        Indication = np.zeros((X[i].shape[0], len(index_com[i])))
                        for j in range(len(index_com[i])):
                            Indication[index_com[i][j], j] = 1
                        Indication = torch.FloatTensor(Indication)
                        Indications.append(Indication)
                    for i in range(args.V):
                        fea_emb_n = Indications[i] @ unfilled_X_complete[i]
                        X_all.append(fea_emb_n)


                    Miss_vecs = []
                    for v in range(args.V):
                        # print('234',missindex[:, v])
                        Miss_vecs.append(missindex[:, v])
                    # print('Miss_vecs',Miss_vecs[0].shape)
                    model = Network(args.V, args.view_dims, args.feature_dim).to(device)
                    optimizer_pretrain = torch.optim.Adam(model.parameters(), lr=args.lr_pre)
                    fea_emb = pretrain(model, optimizer_pretrain, args, device, X_com, Y_com)
                    Labels = Y[0]
                    estimator = KMeans(n_clusters=args.K)

                    fea_cluster2 = fea_emb[0]
                    for i in range(1, len(fea_emb)):
                        fea_cluster2 = np.concatenate((fea_cluster2, fea_emb[i]), axis=1)

                    estimator.fit(fea_cluster2)
                    pred_final2 = estimator.labels_
                    acc, nmi, purity, fscore, precision, recall, ari = evaluate(Labels, pred_final2)
                    print('ACC=%.4f, NMI=%.4f, PUR=%.4f, Fscore=%.4f, Prec=%.4f, Recall=%.4f, ARI=%.4f' %
                          (acc, nmi, purity, fscore, precision, recall, ari))

                    view_matrix = np.zeros((args.V, args.V))
                    metric = 'cosine'
                    entreg = .1
                    p = 2
                    OTLoss = geomloss.SamplesLoss(
                        loss='sinkhorn', p=p,
                        cost=lambda a, b: cost_func(a, b, p=p, metric=metric),
                        blur=entreg ** (1 / p), backend='tensorized')
                    for i in range(args.V):
                        for j in range(i + 1, args.V):
                            common_numbers, index_array1, index_array2 = find_common_elements_with_index(index_com[i],
                                                                                                         index_com[j])
                            if len(common_numbers) > 30000:
                                sample_size = 20000
                                sampled_indices = np.random.choice(common_numbers, sample_size, replace=False)
                                view_matrix[i][j] = OTLoss(fea_emb[i][sampled_indices], fea_emb[j][sampled_indices])
                                view_matrix[j][i] = view_matrix[i][j]
                            else:
                                view_matrix[i][j] = OTLoss(fea_emb[i][common_numbers], fea_emb[j][common_numbers])
                                view_matrix[j][i] = view_matrix[i][j]
                    max_view_graph = generate_max_view_graph(view_matrix)
                    nei_index_matrix = find_nearest_non_missing_view(missindex, view_matrix)
                    nei_index_list_mulview = []
                    for v in range(args.V):
                        nei_index_list_mulview.append(nei_index_matrix[:, v])
                        # print('23',nei_index_matrix[:, v])
                    optimizer_align = torch.optim.Adam(model.parameters(), lr=args.lr_align)
                    fea_end = train_align(model, optimizer_align, args, device, X_all, Y, Miss_vecs, fea_emb,
                                          nei_index_list_mulview, view_matrix)

                    for v in range(args.V):
                        fea_end[v] = fea_end[v].cpu()
                    Labels = Y[0]
                    estimator = KMeans(n_clusters=args.K)

                    fea_cluster2 = fea_end[0]
                    for i in range(1, len(fea_end)):
                        fea_cluster2 = np.concatenate((fea_cluster2, fea_end[i]), axis=1)

                    estimator.fit(fea_cluster2)
                    pred_final2 = estimator.labels_
                    acc, nmi, purity, fscore, precision, recall, ari = evaluate(Labels, pred_final2)
                    name = str(i_d) + '_' + str(missrate) + '_alph=' + str(
                        alph) + '_bata=' + str(beta) + '_' + str('acc=') + str(acc)
                    max_Z = []
                    max_Z.append(acc)
                    max_Z.append(nmi)
                    max_Z.append(purity)
                    max_Z.append(fscore)
                    max_Z.append(recall)
                    max_Z.append(ari)
                    mat_path = 'C:/Users/Admin/Desktop/code/final/SCVT/sen_dao_biamli/{}.mat'.format(name)
                    io.savemat(mat_path, {'max': max_Z})
                    print('ACC=%.4f, NMI=%.4f, PUR=%.4f, Fscore=%.4f, Prec=%.4f, Recall=%.4f, ARI=%.4f' %
                          (acc, nmi, purity, fscore, precision, recall, ari))




