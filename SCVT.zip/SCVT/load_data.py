import numpy as np
import torch
from sklearn.preprocessing import MinMaxScaler
import h5py
import random
import warnings
from visual import t_sne
warnings.filterwarnings("ignore")


# 需要h5py读取

ALL_data3 = dict(
    Sources_3 = {1: 'Sources_3', 'N': 169, 'K': 6, 'V': 3, 'n_input': [3560,3631,3068], 'n_hid': [256,256,256], 'n_output': 64},
    # Washington={1: 'Washington', 'N': 230, 'K': 5, 'V': 4, 'n_input': [230, 1703, 230, 230], 'n_hid': [128, 256, 128, 128], 'n_output': 64},
    # Synthetic3d = {1: 'synthetic3d', 'N': 600, 'K': 3, 'V': 3, 'n_input': [3,3,3], 'n_hid': [2,2,2], 'n_output': 2},
    # UCI_digit = {1: 'UCI_digit', 'N': 2000, 'K': 10, 'V': 3, 'n_input': [64,76,216], 'n_hid': [48,48,64], 'n_output': 32},
    # Cora = {1: 'Cora', 'N': 2708, 'K': 7, 'V': 4, 'n_input': [2708,1433,2708,2708], 'n_hid': [256,256,256,256], 'n_output': 64},
    YouTubeFace10_4Views = {1: 'YouTubeFace10_4Views', 'N': 38654, 'K': 10, 'V':4, 'n_input': [944,576,512,640], 'n_hid': [256,256,256,256], 'n_output': 64},
    # YouTubeFace20_4Views={1: 'YouTubeFace20_4Views', 'N': 63896, 'K': 20, 'V': 4, 'n_input': [944, 576, 512, 640], 'n_hid': [256, 256, 256, 256], 'n_output': 64},
)

path = 'F:/MultiView Dataset/'


def get_mask(view_num, alldata_len, missing_rate):
    '''生成缺失矩阵：
    view_num为视图数
    alldata_len为数据长度
    missing_rate为缺失率
    return 缺失矩阵 alldata_len*view_num大小的0和1矩阵
    '''
    missindex = np.ones((alldata_len, view_num))
    b=((10 - 10*missing_rate)/10) * alldata_len
    miss_begin = int(b)  # 缺失开始的索引
    for i in range(miss_begin, alldata_len):
        missdata = np.random.randint(0, high=view_num,
                                     size=view_num - 1)
        missindex[i, missdata] = 0

    return missindex


def Form_Incomplete_Data(missrate, X = [], Y = []):
    np.random.seed(1)
    size = len(Y[0])
    view_num = len(X)
    index = [i for i in range(size)]
    np.random.shuffle(index)
    for v in range(view_num):
        X[v] = X[v][index]
        Y[v] = Y[v][index]

    ##########################获取缺失矩阵###########################################
    missindex = get_mask(view_num, size, missrate)

    index_complete = []
    index_partial = []
    for i in range(view_num):
        index_complete.append([])
        index_partial.append([])
    for i in range(missindex.shape[0]):
        for j in range(view_num):
            if missindex[i, j] == 1:
                index_complete[j].append(i)
            else:
                index_partial[j].append(i)

    filled_index_com = []
    for i in range(view_num):
        filled_index_com.append([])
    max_len = 0
    for v in range(view_num):
        if max_len < len(index_complete[v]):
            max_len = len(index_complete[v])
    for v in range(view_num):
        if len(index_complete[v]) < max_len:
            diff_len = max_len - len(index_complete[v])
            diff_value = random.sample(index_complete[v], diff_len)
            filled_index_com[v] = index_complete[v] + diff_value
        elif len(index_complete[v]) == max_len:
            filled_index_com[v] = index_complete[v]

    filled_X_complete = []
    filled_Y_complete = []
    unfilled_X_complete = []
    unfilled_Y_complete = []
    for i in range(view_num):
        filled_X_complete.append([])
        filled_Y_complete.append([])
        unfilled_X_complete.append([])
        unfilled_Y_complete.append([])
        filled_X_complete[i] = X[i][filled_index_com[i]]
        filled_Y_complete[i] = Y[i][filled_index_com[i]]
        unfilled_X_complete[i] = X[i][index_complete[i]]
        unfilled_Y_complete[i] = Y[i][index_complete[i]]
    for v in range(view_num):
        X[v] = torch.from_numpy(X[v])
        filled_X_complete[v] = torch.from_numpy(filled_X_complete[v])
        unfilled_X_complete[v] = torch.from_numpy(unfilled_X_complete[v])

    return X, Y, missindex, filled_X_complete, filled_Y_complete, index_complete, index_partial, unfilled_X_complete, unfilled_Y_complete


def load_data(dataset, missrate):
    data = h5py.File(path + dataset[1] + ".mat")
    X = []
    Y = []
    Label = np.array(data['Y']).T
    Label = Label.reshape(Label.shape[0])
    mm = MinMaxScaler()
    for i in range(data['X'].shape[1]):
        diff_view = data[data['X'][0, i]]
        diff_view = np.array(diff_view, dtype=np.float32).T
        print(i)
        if i == 0:
            fig = t_sne(diff_view, Label, diff_view.shape[0], 10000001)
        std_view = mm.fit_transform(diff_view)
        # print('er',std_view)
        X.append(std_view)
        Y.append(Label)
    X, Y, missindex, X_com, Y_com, index_com, index_incom, unfilled_X_complete, unfilled_Y_complete = Form_Incomplete_Data(missrate=missrate, X=X, Y=Y)
    # for i in range(data['X'].shape[1]):
    #     print(index_com[i])
    return X, Y, missindex, X_com, Y_com, index_com, index_incom, unfilled_X_complete, unfilled_Y_complete



