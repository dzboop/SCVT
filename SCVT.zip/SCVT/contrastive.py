import torch
import numpy as np
import torch.nn.functional as F
import random
import torch.nn as nn

def compute_similarity_matrix(features):
    # 归一化特征向量
    features = F.normalize(features, p=2, dim=1)
    similarity_matrix = torch.matmul(features, features.T)
    return similarity_matrix

def get_topk_neighbors(similarity_matrix, k=5):
    _, indices = torch.topk(similarity_matrix, k=k+1, dim=1, largest=True, sorted=True)
    # 移除自身
    indices = indices[:, 1:]
    return indices

def mask_samples(indices, batch_size):
    N = indices.size(0)
    mask = torch.zeros(N, N, dtype=torch.bool)
    for i in range(batch_size):
        mask[i, indices[i]] = 1
    return mask

# def modified_contras_loss(features, temperature):
#     batch_size = features.size(0)
#     similarity_matrix = compute_similarity_matrix(features)
#     topk_neighbors = get_topk_neighbors(similarity_matrix, k=5)
#     mask = mask_samples(topk_neighbors, batch_size)
#     print("similarity_matrix size:", similarity_matrix.shape)
#     pos_sim = similarity_matrix[:batch_size, batch_size:].diagonal()
#     neg_sim = similarity_matrix[mask].reshape(batch_size, -1)
#     print("pos_sim size:", pos_sim.size())
#     print("neg_sim size:", neg_sim.size())
#     loss = pos_sim / neg_sim.sum(dim=1)
#     loss = -torch.log(loss).mean()
#
#     return loss
def modified_contras_loss(z_i, temperature):
    z_i = F.normalize(z_i, p=2, dim=1)
    batch_size = z_i.size(0)
    similarity_matrix = torch.matmul(z_i, z_i.t())
    diag_indices = torch.arange(batch_size, device=z_i.device)
    similarity_matrix[diag_indices, diag_indices] = float('-inf')  # 将对角线元素设为负无穷，防止考虑自身
    _, topk_indices = torch.topk(similarity_matrix, k=6, dim=1)
    k0 = torch.exp(similarity_matrix).sum(dim=1) - torch.exp(similarity_matrix[diag_indices, topk_indices[:, 0]])
    loss_nbr = torch.zeros(batch_size, device=z_i.device)
    for z in range(5):
        loss_nbr += -torch.log(torch.exp(similarity_matrix[diag_indices, topk_indices[:, z+1]]) / k0)
    return loss_nbr.sum() / batch_size


def modified_contras_loss2(z_i, temperature):
    # 归一化特征向量
    z_i = F.normalize(z_i, p=2, dim=1)
    batch_size = z_i.size(0)
    # 计算样本之间的相似度矩阵
    similarity_matrix = torch.matmul(z_i, z_i.t())
    # 获取每个样本的最相似的k个邻居
    _, topk_indices = torch.topk(similarity_matrix, k=6, dim=1)
    # print('topk_indices',topk_indices.shape)
    ################################################
    loss_all_node = torch.FloatTensor([0]).cuda()
    for j in range(batch_size):
        k0 = torch.exp(similarity_matrix[j]).sum() - torch.exp(similarity_matrix[j][j])
        loss_nbr = torch.FloatTensor([0]).cuda()
        for z in range(5):
            if topk_indices[j][z] != j:
                loss_nbr = loss_nbr - torch.log(torch.exp(similarity_matrix[j][int(topk_indices[j][z].item())]) / k0)
        loss_all_node = loss_all_node + loss_nbr
        #########################################################
    # 计算对比学习的损失
    # loss = 0
    # for i in range(batch_size):
    #     pos_sim = similarity_matrix[i, topk_indices[i, 1:]].unsqueeze(0)  # 正样本相似度，去掉自身
    #     neg_sim = torch.cat((similarity_matrix[i, :topk_indices[i, 1]],
    #                          similarity_matrix[i, topk_indices[i, 2:].clamp(min=0)]))  # 负样本相似度
    #     print('pos_sim',pos_sim.shape)
    #     print('neg_sim', neg_sim.shape)
    #     print('pos_sim',pos_sim)
    #     print('neg_sim', neg_sim)
    #     loss += -torch.log(pos_sim / torch.sum(torch.exp(neg_sim / temperature)))
    # loss = loss.sum() / batch_size
    return loss_all_node

def seed_everything(SEED=42):  # 应用不同的种子产生可复现的结果
    random.seed(SEED)
    np.random.seed(SEED)
    torch.manual_seed(SEED)
    torch.cuda.manual_seed(SEED)
    torch.cuda.manual_seed_all(SEED)
    torch.backends.cudnn.benchmark = True  # keep True if all the input have same size.

def mask_correlated_sample(N):
    # N = 2 * args.batch_size
    mask = torch.ones((N, N))
    mask = mask.fill_diagonal_(0)
    for i in range(N // 2):
        mask[i, N // 2 + i] = 0
        mask[N // 2 + i, i] = 0
    mask = mask.bool()
    return mask


# 制造用于区分正负样本的(2Nx2N)大小的mask矩阵
def mask_correlated_samples(batch_size):
    N = 2 * batch_size
    mask = torch.ones((N, N))
    mask = mask.fill_diagonal_(0)
    for i in range(batch_size):
        mask[i, batch_size + i] = 0
        mask[batch_size + i, i] = 0
    mask = mask.bool()
    return mask

######################################
### 第1种 ###
# ####################################
# 原始对比loss # ACC=0.9021
def original_contras_fea(z_i, z_j, temperature):
    # 归一化特征向量
    z_i = F.normalize(z_i, p=2, dim=1)
    z_j = F.normalize(z_j, p=2, dim=1)
    batch_size = z_i.size(0)
    N = 2 * batch_size
    z = torch.cat((z_i, z_j), dim=0)
    dis = torch.matmul(z, z.T)
    # z_abs = z.norm(dim=1)
    # dis = torch.matmul(z, z.T) / torch.einsum('i,j->ij', z_abs, z_abs)
    sim_matrix = torch.exp(dis / temperature)
    sim_i_j = torch.diag(sim_matrix, batch_size)
    sim_j_i = torch.diag(sim_matrix, -batch_size)
    # 原始对比loss
    pos_sim = torch.cat((sim_i_j, sim_j_i), dim=0).reshape(N, 1).squeeze()
    neg_sim = sim_matrix[mask_correlated_samples(batch_size)].reshape(N, -1)

    loss = pos_sim / neg_sim.sum(dim=1)   # 改
    loss = - torch.log1p(loss).mean()

    return loss

def CE_contrastive(z_i, z_j, temperature):
    batch_size = z_i.size(0)
    N = 2 * batch_size
    z = torch.cat((z_i, z_j), dim=0)
    # z_abs = z.norm(dim=1)
    # dis = torch.matmul(z, z.T) / torch.einsum('i,j->ij', z_abs, z_abs)
    dis = z @ z.T
    sim_matrix = dis / temperature
    sim_i_j = torch.diag(sim_matrix, batch_size)
    sim_j_i = torch.diag(sim_matrix, -batch_size)
    pos_sim = torch.cat((sim_i_j, sim_j_i), dim=0).reshape(N, 1)
    neg_sim = sim_matrix[mask_correlated_samples(batch_size)].reshape(N, -1)
    labels = torch.zeros(N).to(pos_sim.device).long()
    logits = torch.cat((pos_sim, neg_sim), dim=1)
    loss = nn.CrossEntropyLoss(reduction="sum")(logits, labels)
    loss /= N





