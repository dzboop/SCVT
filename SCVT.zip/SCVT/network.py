import torch.nn as nn
from torch.nn.functional import normalize
import torch


class Encoder(nn.Module):
    def __init__(self, input_dim, feature_dim):
        super(Encoder, self).__init__()
        self.encoder = nn.Sequential(
            nn.Linear(input_dim, 500),
            nn.ReLU(),
            nn.Linear(500, 500),
            nn.ReLU(),
            nn.Linear(500, 2000),  # 改
            nn.ReLU(),
            nn.Linear(2000, feature_dim),  # 改
        )

    def forward(self, x):
        return self.encoder(x)


class Decoder(nn.Module):
    def __init__(self, input_dim, feature_dim):
        super(Decoder, self).__init__()
        self.decoder = nn.Sequential(
            nn.Linear(feature_dim, 2000),  # 改
            nn.ReLU(),
            nn.Linear(2000, 500),  # 改
            nn.ReLU(),
            nn.Linear(500, 500),
            nn.ReLU(),
            nn.Linear(500, input_dim)
        )

    def forward(self, x):
        return self.decoder(x)


class Network(nn.Module):
    def __init__(self, views, input_size, feature_dim):
        super(Network, self).__init__()
        self.encoders = []
        self.decoders = []
        self.views = views
        for v in range(views):
            self.encoders.append(Encoder(input_size[v], feature_dim))
            self.decoders.append(Decoder(input_size[v], feature_dim))
        self.encoders = nn.ModuleList(self.encoders)
        self.decoders = nn.ModuleList(self.decoders)

    def forward_recon(self, xs, miss_vecs):
        zs, xrs, xs_com = [], [], []
        for v in range(self.views):
            com_idx = torch.where(miss_vecs[v] > 0)[0]
            x = xs[v][com_idx]
            z = self.encoders[v](x)
            # print(z.shape)
            xr = self.decoders[v](z)
            xs_com.append(x)
            zs.append(z)
            xrs.append(xr)
        return zs, xrs, xs_com

    def miss_fill(self, xs, miss_vecs,h_nei_batch):
        zs, xrs, xs_com = [], [], []
        z_filleds = []
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        for v in range(self.views):
            com_idx = torch.where(miss_vecs[v] > 0)[0]
            x = xs[v][com_idx]
            z = self.encoders[v](x)
            # print(z.shape)
            xr = self.decoders[v](z)
            xs_com.append(x)
            zs.append(z)
            xrs.append(xr)
            z_filled = torch.zeros(xs[0].shape[0], z.shape[1]).to(device)
            z_filled[[com_idx]] = z
            z_filleds.append(z_filled)
        n_neighbors = 20
        for j in range(self.views):
            for i in range(h_nei_batch[0].shape[0]):
                # for j in range(h_nei_batch.shape[1]):
                if h_nei_batch[j][i] != -1:
                    neighbor_indices = h_nei_batch[j][i]
                    # 提取邻居特征向量
                    neighbor_features = z_filleds[neighbor_indices]
                    # 计算到查询点的欧氏距离
                    query_point = z_filleds[neighbor_indices][i].unsqueeze(0)  # 将样本转换为二维数组
                    distances = torch.cdist(query_point, neighbor_features.unsqueeze(0), p=2).squeeze(0)
                    # 找到最近的邻居
                    sorted_indices = torch.argsort(distances)[:n_neighbors]
                    valid_neighbors = []

                    for idx in sorted_indices[0]:
                        if h_nei_batch[j][idx] == -1:
                            valid_neighbors.append(idx.item())
                        if len(valid_neighbors) >= 3:
                            break

                    if valid_neighbors:
                        z_filleds[j][i] = torch.mean(z_filleds[j][valid_neighbors], dim=0)
        return zs, xrs, xs_com, z_filleds

    def forward(self, xs):
        zs = []
        xrs = []
        for v in range(self.views):
            x = xs[v]
            z = self.encoders[v](x)
            # print(z.shape)
            xr = self.decoders[v](z)
            zs.append(z)
            xrs.append(xr)
        return zs, xrs