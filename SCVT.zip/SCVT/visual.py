import numpy as np
import random
import matplotlib.pyplot as plt
from sklearn.manifold import TSNE

def t_sne(embeds, labels, sample_num, epoch, show_fig=True):
    """
    visualize embedding by t-SNE algorithm
    :param embeds: embedding of the data
    :param labels: labels
    :param sample_num: the num of samples
    :param show_fig: if show the figure
    :return: figure
    """
    if sample_num > embeds.shape[0]:
        print("Value Error: Sample larger than population")
        return

    # sampling
    random.seed(1)
    sample_index = random.sample(range(0, embeds.shape[0]), sample_num)
    sample_index.sort()
    sample_embeds = embeds[sample_index]
    sample_labels = labels[sample_index]

    # cluster number
    unique = np.unique(sample_labels)
    clusters = np.size(unique, axis=0)
    print(f"Unique labels: {unique}, Clusters: {clusters}")

    # t-SNE
    ts = TSNE(n_components=2, init='pca', random_state=0)
    ts_embeds = ts.fit_transform(sample_embeds[:, :])

    # remove outliers (optional step, not critical for the color issue)
    mean, std = np.mean(ts_embeds, axis=0), np.std(ts_embeds, axis=0)
    filtered_ts_embeds = []
    filtered_labels = []
    for i in range(len(ts_embeds)):
        if (ts_embeds[i] - mean < 3 * std).all():
            filtered_ts_embeds.append(ts_embeds[i])
            filtered_labels.append(sample_labels[i])
    filtered_ts_embeds = np.array(filtered_ts_embeds)
    filtered_labels = np.array(filtered_labels)

    # normalization
    x_min, x_max = np.min(filtered_ts_embeds, 0), np.max(filtered_ts_embeds, 0)
    norm_ts_embeds = (filtered_ts_embeds - x_min) / (x_max - x_min)

    # High contrast color list
    high_contrast_colors = ['#e6194b', '#3cb44b', '#ffe119', '#4363d8', '#f58231',
                            '#911eb4', '#42d4f4', '#f032e6', '#bfef45', '#fabed4',
                            '#469990', '#dcbeff', '#9a6324', '#fffac8', '#800000',
                            '#aaffc3', '#808000', '#ffd8b1', '#000075', '#a9a9a9']

    # plot
    fig = plt.figure()
    for i in range(norm_ts_embeds.shape[0]):
        color = high_contrast_colors[int(filtered_labels[i]) % len(high_contrast_colors)]
        plt.plot(norm_ts_embeds[i, 0], norm_ts_embeds[i, 1],
                 color=color, marker='.', markersize=7)
    plt.xticks([])
    plt.yticks([])
    plt.axis('off')

    # Save figure
    name = str(sample_num) + '_' + str(epoch)
    plt.savefig("C://Users//Admin//Desktop//code//final//SCVT//tsne//{}.png".format(name))
    plt.savefig("C://Users//Admin//Desktop//code//final//SCVT//tsne//{}.eps".format(name), format='eps', dpi=2000)


    return fig


# data_path = "../data/uci-digit_Per0.5.mat"  # 改
# data = loadmat(data_path)
# X = {}
# for i in range(3):
#     diff_view = data['X'][i, 0]
#     diff_view = np.array(diff_view, dtype=np.float32)
#     X.update({str(i): diff_view})
# D = X['2']  # 改
# #sample_num = 500
# sample_num = D.shape[0]
# LABELS = np.array(data['Y'])
# LABELS = np.squeeze(LABELS)
#
# fig = t_sne(D, LABELS, sample_num,30000)


